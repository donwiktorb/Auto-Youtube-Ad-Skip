# Auto-Youtube-Ad-Skip
Auto ad youtube skip
It's extension for firefox
https://addons.mozilla.org/pl/firefox/addon/dwb_yt_ad_skip/
^ public once checked and listed, might still contain bugs